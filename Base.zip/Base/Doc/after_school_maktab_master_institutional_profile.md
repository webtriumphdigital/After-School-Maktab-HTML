# আফটার স্কুল মাকতাব বাংলাদেশ

# Master Institutional Profile & Knowledge Document

**Document type:** Comprehensive Institutional Profile, Educational
Framework & Organizational Knowledge Base\
**Institution:** আফটার স্কুল মাকতাব বাংলাদেশ (After School Maktab
Bangladesh)\
**Associated institution:** দারুল আরকাম ইনস্টিটিউট\
**Primary institutional tagline:** প্রিয় সন্তানের কুরআন ও দ্বীন শেখার আস্থার
ঠিকানা।\
**Document purpose:** To provide a comprehensive, structured, reusable
understanding of the institution for human readers, educators,
administrators, parents, collaborators, and AI systems.

------------------------------------------------------------------------

# Document Control & Interpretation

## Purpose of this document

This document is intended to serve as the central reference document for
understanding আফটার স্কুল মাকতাব বাংলাদেশ. It brings together the
institution's identity, background, educational purpose, teaching areas,
programs, curriculum information, educational methods, intended
outcomes, management information, and known operational context.

It is not written as an advertisement, social media post, admission
notice, or fundraising appeal. It is an institutional knowledge
document.

It may be used as a foundation for preparing:

-   Institutional profiles and introductions.
-   Academic and curriculum documents.
-   Teacher orientation materials.
-   Parent information documents.
-   Internal administrative guidelines.
-   Branch development and standardization plans.
-   Website information architecture and institutional content.
-   Future policy documents and standard operating procedures.
-   AI knowledge bases, assistants, and retrieval systems.

## How to read the information

To avoid confusing confirmed institutional information with
recommendations, this document uses three kinds of statements:

**Established information** --- details explicitly present in the
materials and information supplied about the institution.

**Organized interpretation** --- a careful explanation of the
institution's purpose and educational approach based on those supplied
details. It does not introduce a new official policy.

**Proposed framework / requires institutional approval** --- a
recommended structure, policy area, standard, or future direction that
may be useful, but has not been confirmed as an existing institutional
rule.

Where information is not available, it is identified as unknown or
requiring confirmation. This document does not invent accreditation,
legal status, staffing arrangements, fees, examination rules,
safeguarding policies, or other operational facts.

------------------------------------------------------------------------

# Part I --- Institutional Identity

## 1. Institutional overview

**আফটার স্কুল মাকতাব বাংলাদেশ (After School Maktab Bangladesh)** is an
educational initiative associated with **দারুল আরকাম ইনস্টিটিউট**. Its
central educational purpose is to provide school-going children and
other learners with structured opportunities to learn the Qur'an and
essential Islamic knowledge alongside their regular general education.

The institution's educational concept responds to a practical need:
children who attend mainstream schools also need accessible,
age-appropriate, systematic Islamic education. The institution seeks to
make that education possible through planned lessons, defined learning
areas, a curriculum-based approach, and class batches arranged around
learners' available time.

The program is designed around the idea of learning outside regular
school hours. The supplied materials describe a daily lesson period of
approximately one hour, with multiple batches in the morning, afternoon,
and evening.

The institution's educational scope is not limited to Qur'an recitation
alone. Its stated learning areas include Qur'an, Sunnah, Islamic Aqidah,
Fiqh, and Islamic manners and character. The curriculum information also
refers to practical worship, daily supplications, selected surahs,
hadith, Islamic beliefs, and everyday conduct.

The supplied materials identify several educational divisions under the
institution's broader program concept:

1.  After School Maktab.
2.  After School Hifz.
3.  Farze Ain Maktab.
4.  Masurat Maktab.
5.  Pre-Maktab.

The precise age range, eligibility, curriculum, and operating status of
each division should be documented separately by the institution.

## 2. Name and terminology

**Bangla name:** আফটার স্কুল মাকতাব বাংলাদেশ\
**English name:** After School Maktab Bangladesh

The term *Maktab* refers, in the institution's context, to a structured
setting for foundational Islamic learning. The phrase *After School*
communicates the central scheduling concept: Islamic education is
arranged alongside, rather than in place of, children's mainstream
schooling.

The name therefore communicates two connected ideas:

-   A structured place for Qur'an and essential Islamic education.
-   A learning arrangement designed to fit around the routine of
    school-going learners.

**Institutional tagline:**\
প্রিয় সন্তানের কুরআন ও দ্বীন শেখার আস্থার ঠিকানা।

The tagline expresses the institution's intended role as a trusted
educational environment for children's Qur'an and Islamic learning.

## 3. Institutional relationship

The supplied materials describe আফটার স্কুল মাকতাব বাংলাদেশ as:

**দারুল আরকাম ইনস্টিটিউটের একটি শিক্ষামূলক অঙ্গপ্রতিষ্ঠান।**

The materials also state that Darul Arqam Institute has been conducting
the After School Maktab initiative since 2009 and has prepared an After
School Maktab syllabus.

This establishes the relationship between the Maktab initiative and
Darul Arqam Institute in the institution's own supplied description. The
exact legal, financial, governance, or registration relationship between
the two entities has not been provided and should not be assumed.

## 4. Institutional background and development

According to the supplied brochure, Darul Arqam Institute has been
conducting the After School Maktab program since **2009**. The
initiative was developed to provide school-going learners with Qur'an
education and foundational Islamic knowledge.

The supplied materials also state that a dedicated After School Maktab
syllabus has been prepared for the program. The syllabus is described as
a structured learning resource containing five books, with three
semesters in each book.

The current materials identify a branch in the Nirala residential area
of Khulna.

### Known development points

-   The program is associated with Darul Arqam Institute.
-   The supplied materials identify 2009 as the year from which the
    program has been conducted by Darul Arqam Institute.
-   A dedicated After School Maktab syllabus has been prepared.
-   The syllabus is described as five books, each containing three
    semesters.
-   A Nirala residential-area branch in Khulna has been announced as
    operational in the supplied brochure.

A detailed institutional history---such as the founding circumstances,
original location, founders, year-by-year development, number of
learners, number of branches, and major milestones---has not yet been
supplied.

------------------------------------------------------------------------

# Part II --- Rationale, Philosophy, Mission & Vision

## 5. The educational need

The institution is based on the understanding that mainstream academic
education and Islamic education serve complementary purposes in a
learner's development.

School-going children spend substantial time on formal education.
Without an accessible and planned arrangement, Qur'an learning and
foundational Islamic education may not receive consistent attention in
their daily routines.

The institution seeks to address this need by providing a dedicated
learning opportunity outside regular school hours. Its approach
recognizes that Islamic learning should not be limited to occasional
instruction. Learners need continuity, progression, revision, practice,
and age-appropriate guidance.

The supplied parent message also identifies contemporary concerns such
as excessive device use, weakening moral habits, harmful influences,
poor conduct, and a declining connection with religious learning. These
are presented as reasons why families should take children's Islamic
education seriously.

The institution's educational response is to provide structured learning
in Qur'an, belief, worship, daily Islamic practice, and character.

## 6. Educational philosophy

The educational philosophy reflected in the supplied materials can be
organized around the following principles.

### 6.1 General education and Islamic education are complementary

The institution is designed for learners who participate in mainstream
schooling. Its purpose is to add structured Qur'an and Islamic learning
to their existing educational routine.

### 6.2 Qur'an learning should be systematic

The institution emphasizes planned Qur'an education rather than
unstructured or occasional exposure. Its curriculum includes Qur'an
recitation, selected surahs, memorization-related learning, and a goal
of completing the recitation of the Qur'an correctly.

### 6.3 Islamic knowledge should connect with daily life

The curriculum goes beyond theoretical information. It includes
practical prayer instruction, purification, daily supplications, Sunnah
practices, and everyday Islamic conduct.

### 6.4 Belief, worship, and character belong together

The five stated learning areas---Qur'an, Sunnah, Islamic Aqidah, Fiqh,
and Islamic manners---represent connected dimensions of foundational
Islamic education.

### 6.5 Learning should be appropriate to the learner

The program refers to learners' age, ability, and available time when
describing curriculum design. Separate divisions and batches are
intended to support different learner groups.

### 6.6 Parents are partners in a child's education

The parent-facing material emphasizes the responsibility of parents to
support both general and Islamic education. The curriculum's reference
to prayer charts, semester reports, and parent evaluation also indicates
an intended connection between learning progress and parental awareness.

## 7. Vision

**Proposed institutional vision for approval:**

To contribute to a generation of learners who are connected to the
Qur'an and foundational Islamic knowledge, understand essential beliefs
and worship, practice Islamic manners, and carry their learning into
everyday life while continuing their general education.

This is a proposed formal statement based on the institution's supplied
educational purpose. It should be approved by the institution before
being treated as its official vision statement.

## 8. Mission

**Proposed institutional mission for approval:**

To provide accessible, structured, age-appropriate, and curriculum-based
Qur'an and foundational Islamic education for school-going children and
other learner groups through planned lessons, practical instruction,
continuous learning, and cooperation with parents.

The mission may be understood through the following commitments:

1.  Provide systematic Qur'an learning.
2.  Teach essential Islamic beliefs and foundational knowledge.
3.  Develop understanding of purification, prayer, and other necessary
    acts of worship.
4.  Introduce learners to Sunnah practices and daily supplications.
5.  Support the development of Islamic manners and good conduct.
6.  Organize learning through defined curricula, books, semesters, and
    batches.
7.  Make Islamic learning accessible alongside mainstream education.
8.  Encourage family participation in children's Islamic learning.

## 9. Core educational objectives

The following objectives are derived from the institution's supplied
curriculum and stated goals.

### Qur'anic objectives

-   Help learners develop the ability to read the Qur'an correctly.
-   Support a structured progression in Qur'an recitation.
-   Introduce selected surahs and Qur'anic supplications.
-   Encourage regular engagement with the Qur'an.

### Knowledge objectives

-   Introduce foundational Islamic beliefs.
-   Provide essential knowledge of worship and daily religious practice.
-   Develop familiarity with selected hadith and supplications.
-   Explain relevant Islamic concepts in an age-appropriate manner.

### Practical objectives

-   Teach the practical method of performing salah.
-   Develop familiarity with purification-related requirements.
-   Introduce learners to daily Sunnah practices.
-   Encourage the application of learning in everyday situations.

### Character objectives

-   Develop adab, akhlaq, and good manners.
-   Encourage respectful and responsible conduct.
-   Build an understanding of Islamic values.
-   Support the development of a religiously informed and ethically
    responsible life.

### Educational objectives

-   Maintain continuity through planned lessons.
-   Use books, semesters, lesson plans, and assessment activities.
-   Help parents understand and support learners' progress.
-   Provide learning arrangements that fit around school schedules.

## 10. Core values

The following values are a proposed way of expressing the principles
reflected in the institution's materials. They should be formally
adopted by the institution if intended to serve as official values.

-   **Qur'an-centred learning:** The Qur'an is a central foundation of
    the educational program.
-   **Authentic foundational knowledge:** Islamic learning should be
    grounded in reliable teaching and appropriate scholarship.
-   **Practice and application:** Learners should be encouraged to
    practice what they learn.
-   **Adab and akhlaq:** Good manners and character are integral to
    education.
-   **Consistency:** Regular learning is more meaningful than occasional
    instruction.
-   **Responsibility:** Parents, educators, and administrators each have
    responsibilities in the educational process.
-   **Age-appropriate teaching:** Content and methods should suit the
    learner's stage of development.
-   **Organization:** Curriculum, lesson planning, and assessment should
    support a coherent learning journey.
-   **Respect:** Learners should be treated with dignity and care.

------------------------------------------------------------------------

# Part III --- Learners & Educational Programs

## 11. Intended learner groups

The supplied materials identify school-going learners as the central
audience of the After School Maktab program. They also refer to young
adults, older learners, children aged approximately four to five, and
adult men and women in the broader educational offering.

The learner groups can be organized as follows.

### 11.1 School-going children

This is the principal learner group of After School Maktab. The program
is intended to provide Qur'an and foundational Islamic education outside
regular school hours.

### 11.2 Learners interested in Hifz

The After School Hifz division is described as an opportunity for
learners who are interested in Qur'an memorization and have the aptitude
for it.

### 11.3 Youth and adult learners

Farze Ain Maktab is identified in the supplied materials as a division
for young and adult men, focusing on Qur'an and essential Islamic
knowledge.

### 11.4 Young children

Pre-Maktab is identified for children approximately four to five years
old. The detailed syllabus, readiness requirements, and teaching methods
for this group need separate documentation.

### 11.5 Adult women

The earlier institutional information supplied by the institution refers
to learning opportunities for adult women as well as men. However, the
current brochure does not fully specify the women's program, teacher
arrangements, venue, or batch schedule. These details must be confirmed
before being described as an established operating arrangement.

## 12. Educational divisions

The supplied brochure identifies five divisions. The descriptions below
preserve the available information and distinguish areas where further
details are required.

### 12.1 After School Maktab

**Name:** আফটার স্কুল মাকতাব\
**English:** After School Maktab

**Purpose:** To provide school-going learners with structured Qur'an and
foundational Islamic education after regular school hours.

**Educational scope described in the materials:**

-   Qur'an recitation.
-   Sunnah and daily practices.
-   Islamic Aqidah.
-   Fiqh and essential religious rulings.
-   Islamic manners and character.
-   Practical salah education.
-   Daily supplications and selected hadith.

**Program characteristics:**

-   Curriculum-based learning.
-   Books and semester structure.
-   Planned lessons.
-   Assessment and parent-related reporting elements.
-   Multiple batches at different times of the day.

### 12.2 After School Hifz

**Name:** আফটার স্কুল হিফজ\
**English:** After School Hifz

The supplied materials describe this division as intended for learners
interested in memorizing the Qur'an, particularly those considered
suitable or capable for Hifz.

The following operational details have not been supplied and should be
documented:

-   Admission and readiness criteria.
-   Hifz syllabus and memorization targets.
-   Daily lesson and revision expectations.
-   Teacher qualifications and supervision.
-   Assessment and progress-recording methods.
-   Whether the program is part-time, full-time, or batch-based.
-   Relationship between Hifz study and the learner's mainstream school
    schedule.

### 12.3 Farze Ain Maktab

**Name:** ফরজে আইন মাকতাব\
**English:** Farze Ain Maktab

The supplied materials identify this division for young and adult men.
Its stated scope includes Qur'an and essential Islamic knowledge.

The term *Farze Ain* refers to knowledge that an individual is
personally required to learn. In the institutional context, this
division is intended to address essential knowledge needed for religious
practice and everyday Muslim life.

The exact syllabus, class structure, admission conditions, and timetable
should be documented separately.

### 12.4 Masurat Maktab

**Name in supplied brochure:** মাসুরাত মাকতাব\
**English rendering:** Masurat Maktab (provisional transliteration)

This division is listed in the brochure's program list. The supplied
materials do not provide a detailed explanation of its target learners,
subject matter, curriculum, or operating structure.

The name and spelling, intended meaning, educational purpose, and
program details must be confirmed by the institution. No additional
meaning or curriculum should be assumed until confirmed.

### 12.5 Pre-Maktab

**Name:** প্রি-মাকতাব\
**English:** Pre-Maktab

The supplied materials identify this division for children approximately
four to five years old.

The educational content and teaching approach for this age group should
be documented in a separate early-learning framework. It may need to
account for short attention spans, language development, readiness,
repetition, positive reinforcement, and child-friendly learning
environments. These are recommendations, not confirmed existing
policies.

------------------------------------------------------------------------

# Part IV --- Curriculum & Academic Framework

## 13. The five principal learning areas

The supplied materials identify five central subject areas in the After
School Maktab syllabus.

### 13.1 Qur'an

Qur'an education is a central part of the program. The supplied
curriculum description includes correct Qur'an reading, completion of
Qur'an recitation as a learning goal, selected surahs, and Qur'anic
supplications.

### 13.2 Sunnah

The curriculum refers to Sunnah practices in daily life and the methods
of performing various everyday actions in accordance with the Sunnah.

### 13.3 Islamic Aqidah

The curriculum includes foundational matters of belief, including
Tawhid, Risalah, and Akhirah. It also refers to basic knowledge of
Jannah, Jahannam, and the Hereafter.

### 13.4 Fiqh

The curriculum includes practical rulings related to purification and
salah, as well as introductory knowledge of fasting, Hajj, and Zakat.

### 13.5 Islamic manners and character

The curriculum includes adab, akhlaq, good conduct, and improved
manners. The institution treats these as a distinct part of the
educational program rather than an incidental topic.

## 14. Specific curriculum elements mentioned in the brochure

The supplied materials list the following content:

  -----------------------------------------------------------------------
  Curriculum element                  Quantity or description stated
  ----------------------------------- -----------------------------------
  Selected surahs                     30

  Kalimahs                            6, with meanings

  Qur'anic supplications              10

  Hadith                              40, with meanings

  Asmaul Husna                        99 names of Allah

  Daily supplications                 Common supplications needed in
                                      everyday life

  Sunnah practices                    Methods of various everyday actions

  Salah                               Method of performing the five daily
                                      prayers

  Taharah                             Purification-related rulings

  Aqidah                              Tawhid, Risalah, Akhirah and
                                      foundational beliefs

  Other acts of worship               Introductory knowledge of Sawm,
                                      Hajj and Zakat

  Character                           Adab, Akhlaq and good manners
  -----------------------------------------------------------------------

The brochure does not provide the exact list of the 30 surahs, six
kalimahs, ten supplications, forty hadith, or the detailed sequence of
the Asmaul Husna. Those lists should be included in the official
curriculum appendix when available.

## 15. Curriculum books and semester structure

The supplied brochure states that the After School Maktab syllabus
consists of **five books**.

Each book contains **three semesters**. Each semester has a different
lesson plan and subject content.

The brochure also mentions:

-   Questions and answers at the end of lessons.
-   Salah practice charts.
-   Semester reports.
-   Parent evaluation.

This indicates a curriculum structure that combines learning materials,
planned teaching, practice, and evaluation.

### 15.1 Course duration

The supplied materials list:

-   **After School Maktab Basic Course:** 3 years.
-   **After School Maktab Advanced Course:** 3 years.

The relationship between these two courses is not explained. It must be
confirmed whether the Advanced Course follows the Basic Course, is a
separate pathway, or has another structure. Until then, the two
durations should be recorded separately and should not automatically be
described as a six-year program.

### 15.2 Recommended curriculum documentation

For the curriculum to be fully understandable and consistently
delivered, the institution should maintain the following records:

1.  Book title and edition.
2.  Target age or learner level for each book.
3.  Learning outcomes for each semester.
4.  Lesson-by-lesson teaching plan.
5.  Expected memorization and recitation outcomes.
6.  Revision requirements.
7.  Practical learning activities.
8.  Assessment criteria.
9.  Semester examination structure.
10. Parent reporting format.
11. Teacher guidance notes.
12. Curriculum review history.

These are recommended documentation standards; the supplied materials do
not confirm that all these records currently exist.

## 16. Teaching and learning approach

The institution's materials describe a planned, curriculum-based
approach. They also refer to practical salah teaching, lesson-end
questions and answers, semester reports, and parent evaluation.

A coherent interpretation of this approach includes the following
learning stages:

1.  **Introduction:** Present the topic in a way suitable for the
    learner's age and level.
2.  **Explanation:** Teach the relevant Qur'anic, Islamic, or practical
    knowledge.
3.  **Demonstration:** Demonstrate practical activities where relevant,
    especially worship-related learning.
4.  **Practice:** Give learners opportunities to repeat, recite,
    memorize, or perform the activity.
5.  **Revision:** Reinforce previously taught material.
6.  **Assessment:** Check understanding and practical progress.
7.  **Parent communication:** Share relevant progress information with
    parents.

This seven-stage sequence is a proposed way to formalize the teaching
approach. It should be adopted only if it reflects the institution's
actual academic practice.

------------------------------------------------------------------------

# Part V --- Learning Environment, Assessment & Student Development

## 17. Learning environment and facilities

The supplied brochure lists the following institutional features:

-   Child-friendly, well-arranged classrooms.
-   Teaching by trained ustadhs.
-   A child-appropriate Islamic library.
-   Practical salah education.
-   Special classes on Islamic manners.
-   Topic-based children's religious gatherings.
-   Monitoring and CCTV observation.

The brochure presents these as features of the After School Maktab
program. The exact facilities available at every branch should be
confirmed separately.

## 18. Student assessment and progress monitoring

The supplied curriculum mentions lesson-end question-and-answer
sessions, salah charts, semester reports, and parent evaluation. The
brochure also mentions batch- and semester-based assessment, three
semester-based examinations in a year, and awards.

These details suggest that the institution intends to monitor learning
through more than attendance alone.

### Assessment elements mentioned in the supplied materials

-   Questions and answers after lessons.
-   Salah practice charts.
-   Semester reports.
-   Parent evaluation.
-   Batch-based and semester-based learning assessment.
-   Three examinations per year, described as semester-based.
-   Awards and recognition.

### Recommended areas for a complete student record

The institution may maintain a student record containing:

-   Student identity and guardian contact information.
-   Admission date and assigned division.
-   Batch and teacher information.
-   Attendance.
-   Qur'an reading progress.
-   Memorization progress, where relevant.
-   Subject-wise learning progress.
-   Practical salah learning progress.
-   Assessment and examination results.
-   Areas requiring revision or additional support.
-   Parent meeting notes, where appropriate.

This is a recommended record structure, not a statement that the
institution currently maintains every listed record.

## 19. Student activities and enrichment

The supplied brochure mentions:

-   Topic-based children's religious gatherings.
-   Practical competitions using checklists.
-   An Islamic library suitable for children.
-   Special classes on manners and character.
-   Annual programs.
-   Awards following examinations.

These activities can support learning by giving students opportunities
to revise, demonstrate, discuss, and practice what they have learned.

The exact frequency, format, age groups, and participation rules for
these activities have not been supplied.

## 20. Parent involvement

The institution's parent-facing message treats parents as responsible
partners in a child's Islamic education.

The supplied curriculum also refers to parent evaluation and semester
reports. The brochure lists parent meetings as an institutional feature.

A structured parent partnership may include:

-   Understanding the learner's assigned program and curriculum.
-   Supporting regular attendance.
-   Encouraging Qur'an revision and age-appropriate practice at home.
-   Reviewing progress reports.
-   Communicating learning difficulties to teachers.
-   Participating in scheduled parent meetings.
-   Reinforcing good manners and positive habits at home.

These are recommended ways to make the parent partnership practical.
They should be adapted to the institution's actual policies and the
family's circumstances.

------------------------------------------------------------------------

# Part VI --- Organization, Leadership & Administration

## 21. Leadership information supplied

The supplied materials identify the following leadership roles.

### Supervision

**মুফতি আব্দুল হাই সাহেব (দা.বা.)**

**Position stated:** মুহতামিম, জামিআ উমার বিন খাত্তাব (রাঃ), মুহাম্মাদনগর
মাদরাসা, খুলনা।

### Management / Direction

**মুফতি সাআদ আহমাদ**

The supplied materials identify Mufti Saad Ahmad as the person
responsible for পরিচালনা and also associate him with the educational
curriculum.

The exact formal job titles, decision-making authority, reporting
structure, and administrative responsibilities have not been supplied.

## 22. Known institutional structure

Based on the supplied information, the following relationship can be
described:

-   **দারুল আরকাম ইনস্টিটিউট:** The institution identified as conducting
    the After School Maktab initiative.
-   **আফটার স্কুল মাকতাব বাংলাদেশ:** The educational initiative /
    institutional identity under which the programs are presented.
-   **Supervision:** Mufti Abdul Hai Sahib (da. ba.), as stated in the
    supplied materials.
-   **Management and curriculum direction:** Mufti Saad Ahmad, as stated
    in the supplied materials.
-   **Educational divisions:** After School Maktab, After School Hifz,
    Farze Ain Maktab, Masurat Maktab, and Pre-Maktab.
-   **Branch identified:** Nirala residential area, Khulna.

This is a descriptive map of information provided, not a complete legal
or organizational chart.

## 23. Recommended administrative functions

For a mature and consistently managed institution, the following
functions should be clearly assigned. These are recommended functions,
not confirmed current departments.

### Academic coordination

-   Curriculum implementation.
-   Lesson planning and academic calendars.
-   Teacher guidance.
-   Student assessment.
-   Academic quality review.

### Branch administration

-   Admission and student records.
-   Batch scheduling.
-   Classroom arrangements.
-   Parent communication.
-   Attendance and daily administration.

### Teacher coordination

-   Teacher allocation.
-   Training and orientation.
-   Lesson delivery support.
-   Classroom observation.
-   Professional development.

### Parent and student support

-   Parent meetings.
-   Student progress communication.
-   Attendance follow-up.
-   Learning support and referrals.
-   Handling questions and concerns.

### Quality and institutional development

-   Curriculum review.
-   Branch consistency.
-   Feedback collection.
-   Documentation.
-   Annual planning and review.

------------------------------------------------------------------------

# Part VII --- Time, Batches & Branch Context

## 24. Learning schedule

The supplied materials state that lessons are arranged for:

-   Morning.
-   Afternoon.
-   Evening.

They also state that multiple batches are available and that the daily
learning period is approximately one hour.

The exact batch times, days of operation, weekly frequency, holidays,
and term dates have not been provided.

## 25. Nirala branch

The supplied brochure identifies a branch in the Nirala residential area
of Khulna and states that the branch has been opened.

**Address supplied:**

নিরালা আবাসিক এলাকা, দ্বিতীয় মসজিদ সংলগ্ন, ২২ নং রোড, বাড়ি নং ৪৩১, খুলনা।

**Contact numbers supplied:**

-   ০১৯৪২-০৭৯৫০৭
-   ০১৫৬০০৫২৮৬১

The contact details and current operating status should be checked
before external publication.

## 26. Branch standardization --- proposed framework

If the institution operates or opens more than one branch, it may
benefit from a common branch standard covering:

-   Approved institutional name and identity.
-   Approved curriculum and book editions.
-   Teacher eligibility and orientation.
-   Batch and class scheduling.
-   Admission and student records.
-   Attendance procedures.
-   Assessment and reporting.
-   Parent communication.
-   Classroom and learning environment.
-   Student safety and supervision.
-   Financial and administrative recordkeeping.
-   Periodic academic review.

A branch-specific document should identify which programs are actually
available at that location. The presence of a division in the
institution's overall program list should not automatically imply that
it is active at every branch.

------------------------------------------------------------------------

# Part VIII --- Institutional Quality, Safety & Responsibility

## 27. Educational quality

The institution's stated emphasis on curriculum, semester structure,
trained teachers, assessment, and monitoring provides a foundation for
academic quality.

A formal quality framework could include:

-   Consistent use of approved curriculum materials.
-   Clear lesson objectives.
-   Appropriate teacher preparation.
-   Regular revision and assessment.
-   Monitoring of student progress.
-   Parent feedback.
-   Periodic curriculum review.
-   Documentation of changes and improvements.

These are recommended quality practices and should be formalized by the
institution.

## 28. Child welfare and safeguarding

Because the institution serves children, student welfare should be
treated as an essential administrative and educational responsibility.

The supplied brochure mentions monitoring and CCTV observation. It does
not provide a complete child safeguarding policy.

The institution should consider formally documenting:

-   Student arrival and departure procedures.
-   Authorized collection of children.
-   Classroom supervision.
-   Appropriate teacher-student boundaries.
-   A process for reporting concerns.
-   Safe and respectful discipline.
-   Emergency contact procedures.
-   First-aid and emergency response arrangements.
-   Privacy and responsible handling of student information.
-   CCTV access, retention, and privacy rules.
-   Procedures for trips, events, and off-site activities, if any.

These points are recommendations for policy development, not claims
about current institutional arrangements. Any CCTV use should comply
with applicable law and respect the privacy and dignity of students and
families.

## 29. Respectful and supportive learning

The institution may define a written learner conduct and discipline
policy based on dignity, fairness, age-appropriate expectations, and
constructive guidance.

A recommended approach would include:

-   Respectful communication.
-   No humiliation or degrading treatment.
-   Clear classroom expectations.
-   Encouragement and positive reinforcement.
-   Appropriate responses to repeated disruption.
-   Fair treatment of learners.
-   Consideration of age, ability, and individual learning needs.

The exact discipline policy should be approved by institutional
leadership.

## 30. Privacy and student information

Student records, parent contact details, examination results,
photographs, and CCTV footage can contain personal information.

The institution should define:

-   What information is collected.
-   Why each item is needed.
-   Who may access it.
-   How it is stored and protected.
-   When it may be shared.
-   How long it is retained.
-   How parents can request corrections.
-   How photographs and recordings may be used.

No specific privacy policy has been supplied, so this section is a
recommended policy area.

------------------------------------------------------------------------

# Part IX --- Institutional Communication & Knowledge Management

## 31. Official institutional information

The following details are available from the supplied materials.

  -----------------------------------------------------------------------
  Item                                Available information
  ----------------------------------- -----------------------------------
  Bangla name                         আফটার স্কুল মাকতাব বাংলাদেশ

  English name                        After School Maktab Bangladesh

  Associated institution              দারুল আরকাম ইনস্টিটিউট

  Tagline                             প্রিয় সন্তানের কুরআন ও দ্বীন শেখার
                                      আস্থার ঠিকানা।

  Program history                     Darul Arqam Institute has conducted
                                      the initiative since 2009,
                                      according to the brochure

  Main educational focus              Qur'an and foundational Islamic
                                      education

  Five learning areas                 Qur'an, Sunnah, Islamic Aqidah,
                                      Fiqh, Islamic manners

  Program divisions                   After School Maktab, After School
                                      Hifz, Farze Ain Maktab, Masurat
                                      Maktab, Pre-Maktab

  Curriculum structure                Five books; three semesters in each
                                      book

  Course durations stated             Basic: 3 years; Advanced: 3 years

  Daily lesson duration               Approximately 1 hour

  Batch times                         Morning, afternoon, evening

  Supervision                         Mufti Abdul Hai Sahib (da. ba.)

  Management / curriculum direction   Mufti Saad Ahmad

  Identified branch                   Nirala residential area, Khulna

  Contact numbers                     ০১৯৪২-০৭৯৫০৭; ০১৫৬০০৫২৮৬১
  -----------------------------------------------------------------------

## 32. Recommended institutional document library

To make institutional knowledge accessible to staff, parents, and future
AI systems, the institution should maintain a controlled collection of
documents.

Suggested documents include:

1.  Master Institutional Profile.
2.  Institutional vision, mission, and values.
3.  Institutional history and milestones.
4.  Organizational structure and role descriptions.
5.  Program descriptions for each division.
6.  Full curriculum and book contents.
7.  Semester-wise syllabus.
8.  Lesson plans and teacher guidance.
9.  Admission and enrollment policy.
10. Student attendance policy.
11. Assessment and examination policy.
12. Parent communication guidelines.
13. Teacher recruitment and orientation guidelines.
14. Student welfare and safeguarding policy.
15. Privacy and information management policy.
16. Branch operations handbook.
17. Financial and fee policy, if applicable.
18. Annual academic calendar.
19. Institutional reports and performance reviews.

These are recommended documents. Their existence should not be assumed
until confirmed.

## 33. Recommended knowledge structure for AI systems

If this document is used as a knowledge source for an AI assistant, the
following information should ideally be maintained as separate,
authoritative records:

-   **Identity:** Official name, Bangla and English spellings,
    institutional relationship, address, contact information.
-   **History:** Verified timeline and milestones.
-   **Governance:** Leadership, supervision, roles, and decision
    authority.
-   **Programs:** Each division's purpose, eligibility, curriculum,
    duration, and current availability.
-   **Curriculum:** Books, subjects, lessons, semester plans,
    memorization lists, and learning outcomes.
-   **Operations:** Batch schedules, attendance, admission, holidays,
    and branch details.
-   **People:** Approved staff roles and public professional
    biographies.
-   **Policies:** Approved rules for students, parents, teachers,
    safety, privacy, and administration.
-   **Updates:** Effective date, approving authority, and version
    history for each change.

An AI assistant should be instructed to distinguish official
institutional facts from proposed ideas, avoid inventing missing
details, and direct users to the institution for information that is not
documented.

------------------------------------------------------------------------

# Part X --- Strategic Development

## 34. Long-term institutional direction

The supplied materials establish the institution's educational purpose
and identify its curriculum and divisions. They do not provide an
approved long-term strategic plan.

The following areas may be considered for future institutional
development. They are strategic possibilities, not announced
commitments.

### 34.1 Curriculum development

-   Complete and document all book contents.
-   Define learning outcomes for each semester.
-   Prepare teacher guidance for each lesson.
-   Establish a consistent revision and assessment approach.
-   Review curriculum content periodically.

### 34.2 Teacher development

-   Define teacher qualifications for each division.
-   Provide orientation on the institution's educational approach.
-   Develop teaching resources.
-   Encourage ongoing academic development.
-   Establish a consistent teacher feedback process.

### 34.3 Student learning support

-   Track individual learning progress.
-   Identify learners who need additional support.
-   Improve revision and practice arrangements.
-   Encourage positive participation.
-   Make assessment informative and constructive.

### 34.4 Parent partnership

-   Provide understandable progress reports.
-   Establish regular parent communication.
-   Explain the curriculum and learning expectations.
-   Encourage realistic home-learning support.

### 34.5 Branch development

-   Define minimum branch standards.
-   Maintain consistency in curriculum and identity.
-   Document local program availability.
-   Establish a periodic branch review process.

### 34.6 Digital administration

A digital system could support admissions, student profiles, attendance,
batch management, teacher allocation, assessment, progress reports,
parent communication, and institutional records.

This is a possible future operational improvement, not a statement that
such a system currently exists.

## 35. Possible institutional performance indicators

If the institution wants to assess its effectiveness, it may define
indicators such as:

-   Student enrollment and retention.
-   Attendance and regular participation.
-   Qur'an reading progress.
-   Memorization progress, where applicable.
-   Completion of planned lessons.
-   Semester assessment outcomes.
-   Practical salah learning progress.
-   Parent participation and feedback.
-   Teacher attendance and development.
-   Curriculum completion.
-   Student welfare incidents and resolution.
-   Branch-level consistency.

Indicators should be selected carefully. The purpose should be to
improve learning and institutional quality, not to reduce Islamic
education to numerical targets alone.

------------------------------------------------------------------------

# Part XI --- Information Gaps & Verification Register

## 36. Details that require institutional confirmation

The current source materials provide a meaningful overview, but they do
not contain every detail needed for a fully authoritative institutional
record.

The following points should be confirmed by the institution.

### Identity and history

-   Exact official English spelling and any approved short name.
-   Formal institutional status and legal relationship with Darul Arqam
    Institute.
-   Founding date and a verified history of the initiative.
-   Meaning and approved Arabic rendering of the institutional name, if
    used.
-   Registration number ১৭৫: issuing authority, scope, and current
    validity, if this number is intended to be used institutionally.

### Programs

-   Exact spelling and meaning of Masurat Maktab.
-   Detailed purpose and learner group for each division.
-   Which divisions are currently active.
-   Whether adult women's classes are currently offered.
-   Whether separate facilities, teachers, or batches are arranged for
    women.
-   Age and admission criteria for each program.
-   Whether Hifz is part-time or follows another schedule.

### Curriculum

-   Names and contents of the five books.
-   The exact list of 30 surahs.
-   The exact six kalimahs.
-   The exact ten Qur'anic supplications.
-   The selected forty hadith.
-   The order and teaching method for Asmaul Husna.
-   Detailed lesson plans and semester learning outcomes.
-   Whether Basic and Advanced courses are sequential or independent.
-   How the three semesters and annual three examinations align.
-   Whether the curriculum has an approved edition or revision date.

### Academic operations

-   Exact batch timings and weekly schedule.
-   Academic calendar and holidays.
-   Class size and teacher-student ratio.
-   Teacher qualifications and training requirements.
-   Admission and placement procedures.
-   Examination and grading method.
-   Attendance requirements.
-   Student promotion and course completion rules.

### Administration and governance

-   Formal titles and responsibilities of leadership.
-   Administrative reporting structure.
-   Branch management roles.
-   Fee structure, scholarships, and financial procedures, if
    applicable.
-   Parent complaint and feedback process.
-   Approved safeguarding and privacy policies.

### Branch and contact information

-   Current operating status of the Nirala branch.
-   Which programs are active at the Nirala branch.
-   Confirmation of the address and phone numbers.
-   Whether additional branches exist.
-   Branch-specific schedules and facilities.

## 37. Important distinctions

For accuracy, the following distinctions should be maintained in all
future institutional documents:

1.  A program listed in the institution's overall brochure is not
    necessarily active at every branch.
2.  A proposed policy is not an approved policy until leadership adopts
    it.
3.  A curriculum topic mentioned in a brochure does not replace a full
    syllabus or lesson plan.
4.  A stated course duration does not establish whether two courses are
    sequential.
5.  A stated institutional relationship does not establish a legal or
    ownership structure.
6.  A listed registration number should not be described as government
    accreditation or legal recognition unless its issuing authority and
    meaning are verified.
7.  The availability of women's classes, Hifz classes, and other
    specialized arrangements should be confirmed for each branch.

------------------------------------------------------------------------

# Part XII --- Institutional Summary

## 38. Comprehensive summary

আফটার স্কুল মাকতাব বাংলাদেশ (After School Maktab Bangladesh) is an
educational initiative associated with দারুল আরকাম ইনস্টিটিউট. According
to the supplied institutional brochure, Darul Arqam Institute has been
conducting the initiative since 2009 and has prepared a dedicated After
School Maktab syllabus.

The institution's central purpose is to provide school-going children
with structured Qur'an and foundational Islamic education alongside
their mainstream schooling. Its educational philosophy connects Qur'an
learning, Sunnah, Islamic Aqidah, Fiqh, and Islamic manners. It
emphasizes not only knowledge but also practical understanding of
worship, daily supplications, Sunnah practices, and good conduct.

The supplied materials identify five educational divisions: After School
Maktab, After School Hifz, Farze Ain Maktab, Masurat Maktab, and
Pre-Maktab. The main After School Maktab syllabus is described as five
books, with three semesters in each book. The stated course durations
are three years for the Basic Course and three years for the Advanced
Course, although the relationship between the two requires confirmation.

The curriculum includes selected surahs, kalimahs with meanings,
Qur'anic supplications, hadith with meanings, Asmaul Husna, daily
supplications, Sunnah practices, purification, salah, foundational
Aqidah, and introductory knowledge of fasting, Hajj, and Zakat. Adab,
Akhlaq, and Islamic manners are also included.

The educational arrangement is designed around approximately one hour of
daily learning, with multiple batches in the morning, afternoon, and
evening. The brochure lists child-friendly classrooms, trained teachers,
practical salah instruction, an Islamic library, topic-based religious
gatherings, practical activities, monitoring, semester assessments,
examinations, awards, parent meetings, and annual programs as features
of the initiative.

The supplied leadership information identifies Mufti Abdul Hai Sahib
(da. ba.) in a supervisory capacity and Mufti Saad Ahmad in a management
and curriculum-related capacity. The materials identify a branch in the
Nirala residential area of Khulna, near the Second Mosque, at Road 22,
House 431.

The institution's central educational idea can be expressed as follows:

**To make systematic Qur'an and foundational Islamic education
accessible to school-going children and other learners, and to help them
connect Islamic knowledge with belief, worship, manners, and everyday
life.**

## 39. One-paragraph institutional description

আফটার স্কুল মাকতাব বাংলাদেশ হলো দারুল আরকাম ইনস্টিটিউটের একটি শিক্ষামূলক
অঙ্গপ্রতিষ্ঠান, যার লক্ষ্য স্কুলগামী শিক্ষার্থী ও অন্যান্য উপযুক্ত learner group-এর
জন্য নিয়মতান্ত্রিক কুরআন ও মৌলিক দ্বীনি শিক্ষার সুযোগ তৈরি করা। ২০০৯ সাল থেকে
পরিচালিত এ কার্যক্রমে কুরআন, সুন্নাহ, ইসলামী আকিদা, ফিকহ এবং ইসলামী
শিষ্টাচারকে শিক্ষার মূল ক্ষেত্র হিসেবে বিবেচনা করা হয়েছে। পাঁচটি বই ও
সেমিস্টারভিত্তিক কাঠামোয় প্রস্তুত সিলেবাসে কুরআন তিলাওয়াত, নির্বাচিত সূরা,
কালিমা, দোয়া, হাদিস, আসমাউল হুসনা, তাহারাত, সালাত, মৌলিক আকিদা, ইবাদত এবং
আদব-আখলাক অন্তর্ভুক্ত রয়েছে। প্রতিদিন প্রায় এক ঘণ্টা করে সকাল, বিকাল ও সন্ধ্যায়
একাধিক ব্যাচে পাঠদানের ধারণা নিয়ে আফটার স্কুল মাকতাব, আফটার স্কুল হিফজ, ফরজে
আইন মাকতাব, মাসুরাত মাকতাব ও প্রি-মাকতাব বিভাগ পরিচালনার কথা প্রতিষ্ঠানের
প্রচারপত্রে উল্লেখ রয়েছে।

------------------------------------------------------------------------

# Appendix A --- Source Basis

This document has been prepared from:

1.  The front-side brochure image supplied in the conversation.
2.  The inside-page brochure image supplied in the conversation.
3.  The institution name, tagline, program descriptions, contact
    information, and additional institutional details supplied in the
    conversation.
4.  The previously prepared institutional concept material, used as an
    organized summary rather than as an independent source of new facts.

Where the materials differ or do not provide sufficient detail, the
document identifies the point for confirmation rather than silently
resolving it.

# Appendix B --- Versioning & Maintenance

This document should be treated as a living institutional reference.

Recommended maintenance practice:

-   Assign a document owner.
-   Record the approving authority.
-   Add a version number and effective date.
-   Record material changes to programs and curriculum.
-   Update branch and contact information when it changes.
-   Review leadership and governance information periodically.
-   Keep proposed policies separate from approved policies.
-   Preserve previous approved versions for institutional reference.

**Suggested document status:** Draft master institutional profile ---
requires review and approval by institutional leadership.

**End of document.**
